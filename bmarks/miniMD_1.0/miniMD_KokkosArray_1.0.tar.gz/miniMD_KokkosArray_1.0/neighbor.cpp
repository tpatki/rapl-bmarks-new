/* ----------------------------------------------------------------------
   miniMD is a simple, parallel molecular dynamics (MD) code.   miniMD is
   an MD microapplication in the Mantevo project at Sandia National
   Laboratories ( http://www.mantevo.org ). The primary
   authors of miniMD are Steve Plimpton (sjplimp@sandia.gov) , Paul Crozier
   (pscrozi@sandia.gov) and Christian Trott (crtrott@sandia.gov).

   Copyright (2008) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This library is free software; you
   can redistribute it and/or modify it under the terms of the GNU Lesser
   General Public License as published by the Free Software Foundation;
   either version 3 of the License, or (at your option) any later
   version.

   This library is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this software; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
   USA.  See also: http://www.gnu.org/licenses/lgpl.txt .

   For questions, contact Paul S. Crozier (pscrozi@sandia.gov) or
   Christian Trott (crtrott@sandia.gov).

   Please read the accompanying README and LICENSE files.
---------------------------------------------------------------------- */

#include "stdio.h"
#include "stdlib.h"

#include "neighbor.h"

#define FACTOR 0.999
#define SMALL 1.0e-6

Neighbor::Neighbor()
{
  ncalls = 0;
  max_totalneigh = 0;
  maxneighs = 100;
  nmax = 0;
  atoms_per_bin = 8;
  threads = NULL;
  halfneigh = 0;
  resize = tscalar_i("Resize");
  new_maxneighs = tscalar_i("NewMaxneighs");
  h_resize = KokkosArray::create_mirror_view(resize);
  h_new_maxneighs = KokkosArray::create_mirror_view(new_maxneighs);
  ghost_newton = 1;
  nbinx = -1;
  nbiny = -1;
  nbinz = -1;

}

Neighbor::~Neighbor()
{
}

void Neighbor::finalise()
{
  delete f_binatoms;
  delete f_build;
}


/* binned neighbor list construction with full Newton's 3rd law
   every pair stored exactly once by some processor
   each owned atom i checks its own bin and other bins in Newton stencil */
KokkosArrayCUDA(
  KokkosArray::CudaWorkConfig Neighbor::build_set_launch_config()
{
  KokkosArray::CudaWorkConfig config;

  //CUDA specialisation
  config.grid[0] = mbins;

  if(mbins > 65000) {
    MMD_int maxbindim = mbinx > mbiny ? mbinx : mbiny;
    maxbindim = maxbindim > mbinz ? maxbindim : mbinz;
    config.grid[0] = maxbindim;
    config.grid[1] = mbins / maxbindim;
  }

  config.block[0] = atoms_per_bin;
  config.shared = atoms_per_bin * 4 * sizeof(MMD_float);

  return config;
}
)

void Neighbor::build_Item(const MMD_int &i) const
{
  /* if necessary, goto next page and add pages */

  MMD_int n = 0;

  const MMD_float xtmp = x(i, 0);
  const MMD_float ytmp = x(i, 1);
  const MMD_float ztmp = x(i, 2);

  /* loop over atoms in i's bin,
  */

  const MMD_int ibin = coord2bin(xtmp, ytmp, ztmp);

  for(MMD_int k = 0; k < nstencil; k++) {
    const MMD_int jbin = ibin + stencil[k];

    int* loc_bin = &bins[jbin * atoms_per_bin];

    if(ibin == jbin)
      for(int m = 0; m < bincount[jbin]; m++) {
        MMD_int j = loc_bin[m];

        //for same bin as atom i skip j if i==j and skip atoms "below and to the left" if using halfneighborlists
        if((j == i) || (halfneigh && !ghost_newton && (j < i))  ||
            (halfneigh && ghost_newton && ((j < i) || ((j >= nlocal) &&
                                           ((x(j, 2) < ztmp) || (x(j, 2) == ztmp && x(j, 1) < ytmp) ||
                                            (x(j, 2) == ztmp && x(j, 1)  == ytmp && x(j, 0) < xtmp)))))
          ) continue;

        const MMD_float delx = xtmp - x(j, 0);
        const MMD_float dely = ytmp - x(j, 1);
        const MMD_float delz = ztmp - x(j, 2);
        const MMD_float rsq = delx * delx + dely * dely + delz * delz;

        if((rsq <= cutneighsq)) neighbors(i, n++) = j;
      }
    else {
      for(int m = 0; m < bincount[jbin]; m++) {
        const MMD_int j = loc_bin[m];

        if(halfneigh && !ghost_newton && (j < i)) continue;

        const MMD_float delx = xtmp - x(j, 0);
        const MMD_float dely = ytmp - x(j, 1);
        const MMD_float delz = ztmp - x(j, 2);
        const MMD_float rsq = delx * delx + dely * dely + delz * delz;

        if((rsq <= cutneighsq)) neighbors(i, n++) = j;
      }
    }
  }

  numneigh[i] = n;

  if(n >= maxneighs) {
    resize(0) = 1;

    if(n >= new_maxneighs(1)) new_maxneighs(1) = n;
  }
}



#if DEVICE==2
extern __shared__ MMD_float sharedmem[];
__device__ inline void Neighbor::build_ItemCuda(const MMD_int &ii) const
{

  /* loop over atoms in i's bin,
  */
  MMD_int ibin = blockIdx.x * gridDim.y + blockIdx.y;
  MMD_float* other_x = sharedmem;
  MMD_int* other_id = (MMD_int*) &other_x[3 * blockDim.x];

  MMD_int bincount_current = bincount[ibin];
  MMD_int i = threadIdx.x < bincount_current ? bins[ibin * atoms_per_bin + threadIdx.x] : -1;
  /* if necessary, goto next page and add pages */

  MMD_int n = 0;

  MMD_float xtmp;
  MMD_float ytmp;
  MMD_float ztmp;

  if(i >= 0) {
    xtmp = x(i, 0);
    ytmp = x(i, 1);
    ztmp = x(i, 2);
    other_x[threadIdx.x] = xtmp;
    other_x[threadIdx.x + blockDim.x] = ytmp;
    other_x[threadIdx.x + 2 * blockDim.x] = ztmp;
  }

  other_id[threadIdx.x] = i;
  int test = (__syncthreads_count(i >= 0 && i <= nlocal) == 0);

  if(test) return;

  if(i >= 0 && i < nlocal)
    for(int m = 0; m < bincount_current; m++) {
      MMD_int j = other_id[m];

      //for same bin as atom i skip j if i==j and skip atoms "below and to the left" if using halfneighborlists
      //if(j==i) continue;
      if((j == i) || (halfneigh && (j < i)))  continue;

      const MMD_float delx = xtmp - other_x[m];
      const MMD_float dely = ytmp - other_x[m + blockDim.x];
      const MMD_float delz = ztmp - other_x[m + 2 * blockDim.x];
      const MMD_float rsq = delx * delx + dely * dely + delz * delz;

      if((rsq <= cutneighsq) && (n < maxneighs)) neighbors(i, n++) = j;

      //if ((rsq <= cutneighsq)&&(n<maxneighs)) neighptr[n++*nlocal] = j;
    }

  __syncthreads();

  for(MMD_int k = 0; k < nstencil; k++) {
    const MMD_int jbin = ibin + stencil[k];

    if(ibin == jbin) continue;

    //if(jbin>mbins) continue;
    bincount_current = bincount[jbin];
    MMD_int j = threadIdx.x < bincount_current ? bins[jbin * atoms_per_bin + threadIdx.x] : -1;

    if(j >= 0) {
      other_x[threadIdx.x] = x(j, 0);
      other_x[threadIdx.x + blockDim.x] = x(j, 1);
      other_x[threadIdx.x + 2 * blockDim.x] = x(j, 2);
    }

    other_id[threadIdx.x] = j;


    __syncthreads();

    if(i >= 0 && i < nlocal)
      for(int m = 0; m < bincount_current; m++) {
        const MMD_int j = other_id[m];

        if(halfneigh && (j < i))  continue;

        const MMD_float delx = xtmp - other_x[m];
        const MMD_float dely = ytmp - other_x[m + blockDim.x];
        const MMD_float delz = ztmp - other_x[m + 2 * blockDim.x];
        const MMD_float rsq = delx * delx + dely * dely + delz * delz;

        if((rsq <= cutneighsq) && (n < maxneighs)) neighbors(i, n++) = j;

        //if ((rsq <= cutneighsq)&&(n<maxneighs)) neighptr[n++*nlocal] = j;
      }

    __syncthreads();
  }

  if(i >= 0 && i < nlocal)
    numneigh[i] = n;

  if(n >= maxneighs) {
    resize(0) = 1;

    if(n >= new_maxneighs(1)) new_maxneighs(1) = n;
  }
}
#endif

void Neighbor::build(Atom &atom)
{
  ncalls++;
  nlocal = atom.nlocal;
  nall = atom.nlocal + atom.nghost;
  /* extend atom arrays if necessary */

  x = atom.x;

  if(nall > nmax) {
    nmax = nall;
    numneigh = tvector_1i("numneigh", nmax);
    h_numneigh = KokkosArray::create_mirror_view(numneigh);
    neighbors = tvector_neighbors("neighbors", nmax, maxneighs);
  }

  /* bin local & ghost atoms */
  binatoms(atom);
  count = 0;
  /* loop over each atom, storing neighbors */

  h_resize(0) = 1;

  timer->stamp_extra_start();

  while(h_resize(0)) {
    h_new_maxneighs(0) = maxneighs;
    h_resize(0) = 0;

    KokkosArray::deep_copy(resize, h_resize);
    deep_copy(new_maxneighs, h_new_maxneighs);

    KokkosArrayCUDA(
      const KokkosArray::CudaWorkConfig config = build_set_launch_config();
    )
    KokkosArrayHost(int config = nlocal;)

    f_build->c = *this;
    KokkosArray::parallel_for(config, *f_build);
    device_type::fence();

    deep_copy(h_resize, resize);

    if(h_resize(0)) {
      deep_copy(h_new_maxneighs, new_maxneighs);
      maxneighs = h_new_maxneighs(0) * 1.2;
      neighbors = tvector_neighbors("neighbors", nmax, maxneighs);
    }
  }

  timer->stamp_extra_stop(TIME_TEST);
}



inline void Neighbor::binatoms(Atom &atom)
{
  nlocal = atom.nlocal;
  nall = atom.nlocal + atom.nghost;
  x = atom.x;

  xprd = atom.box.xprd;
  yprd = atom.box.yprd;
  zprd = atom.box.zprd;

  h_resize(0) = 1;


  while(h_resize(0) > 0) {
    h_resize(0) = 0;
    deep_copy(resize, h_resize);

    MemsetZeroFunctor f_zero;
    f_zero.ptr = (void*) bincount.ptr_on_device();
    //KokkosArray::parallel_for(0,f_zero);
    KokkosArray::parallel_for(mbins, f_zero);
    device_type::fence();

    f_binatoms->c = *this;
    //KokkosArray::parallel_for(0,*f_binatoms);
    KokkosArray::parallel_for(nall, *f_binatoms);
    device_type::fence();

    deep_copy(h_resize, resize);

    if(h_resize(0)) {
      atoms_per_bin *= 2;
      bins = tvector_1i("bins", mbins * atoms_per_bin);
    }
  }
}

KOKKOSARRAY_INLINE_FUNCTION void Neighbor::binatomsItem(const MMD_int &i) const
{
  const MMD_int ibin = coord2bin(x(i, 0), x(i, 1), x(i, 2));
  //volatile MMD_int* bc = &bincount[ibin];
  //const MMD_int ac = __sync_fetch_and_add(bc, 1);


#if __CUDA_ARCH__
  const MMD_int ac = atomicAdd(&bincount[ibin], 1);
#else
  const MMD_int ac = __sync_fetch_and_add(&bincount[ibin], 1);
#endif

  if(ac < atoms_per_bin) {
    bins[ibin * atoms_per_bin + ac] = i;
  } else resize(0) = 1;
}

/* convert xyz atom coords into local bin #
   take special care to insure ghost atoms with
   coord >= prd or coord < 0.0 are put in correct bins */

KOKKOSARRAY_INLINE_FUNCTION int Neighbor::coord2bin(MMD_float x, MMD_float y, MMD_float z) const
{
  MMD_int ix, iy, iz;

  if(x >= xprd)
    ix = (MMD_int)((x - xprd) * bininvx) + nbinx - mbinxlo;
  else if(x >= 0.0)
    ix = (MMD_int)(x * bininvx) - mbinxlo;
  else
    ix = (MMD_int)(x * bininvx) - mbinxlo - 1;

  if(y >= yprd)
    iy = (MMD_int)((y - yprd) * bininvy) + nbiny - mbinylo;
  else if(y >= 0.0)
    iy = (MMD_int)(y * bininvy) - mbinylo;
  else
    iy = (MMD_int)(y * bininvy) - mbinylo - 1;

  if(z >= zprd)
    iz = (MMD_int)((z - zprd) * bininvz) + nbinz - mbinzlo;
  else if(z >= 0.0)
    iz = (MMD_int)(z * bininvz) - mbinzlo;
  else
    iz = (MMD_int)(z * bininvz) - mbinzlo - 1;

  return (iz * mbiny * mbinx + iy * mbinx + ix + 1);
}


/*
setup neighbor binning parameters
bin numbering is global: 0 = 0.0 to binsize
                         1 = binsize to 2*binsize
                         nbin-1 = prd-binsize to binsize
                         nbin = prd to prd+binsize
                         -1 = -binsize to 0.0
coord = lowest and highest values of ghost atom coords I will have
        add in "small" for round-off safety
mbinlo = lowest global bin any of my ghost atoms could fall into
mbinhi = highest global bin any of my ghost atoms could fall into
mbin = number of bins I need in a dimension
stencil() = bin offsets in 1-d sense for stencil of surrounding bins
*/

int Neighbor::setup(Atom &atom)
{
  MMD_int i, j, k, nmax;
  MMD_float coord;
  MMD_int mbinxhi, mbinyhi, mbinzhi;
  MMD_int nextx, nexty, nextz;
  MMD_int num_omp_threads = threads->omp_num_threads;

  cutneighsq = cutneigh * cutneigh;

  xprd = atom.box.xprd;
  yprd = atom.box.yprd;
  zprd = atom.box.zprd;

  /*
  c bins must evenly divide into box size,
  c   becoming larger than cutneigh if necessary
  c binsize = 1/2 of cutoff is near optimal

  if (flag == 0) {
    nbinx = 2.0 * xprd / cutneigh;
    nbiny = 2.0 * yprd / cutneigh;
    nbinz = 2.0 * zprd / cutneigh;
    if (nbinx == 0) nbinx = 1;
    if (nbiny == 0) nbiny = 1;
    if (nbinz == 0) nbinz = 1;
  }
  */

  binsizex = xprd / nbinx;
  binsizey = yprd / nbiny;
  binsizez = zprd / nbinz;
  bininvx = 1.0 / binsizex;
  bininvy = 1.0 / binsizey;
  bininvz = 1.0 / binsizez;

  coord = atom.box.xlo - cutneigh - SMALL * xprd;
  mbinxlo = static_cast<int>(coord * bininvx);

  if(coord < 0.0) mbinxlo = mbinxlo - 1;

  coord = atom.box.xhi + cutneigh + SMALL * xprd;
  mbinxhi = static_cast<int>(coord * bininvx);

  coord = atom.box.ylo - cutneigh - SMALL * yprd;
  mbinylo = static_cast<int>(coord * bininvy);

  if(coord < 0.0) mbinylo = mbinylo - 1;

  coord = atom.box.yhi + cutneigh + SMALL * yprd;
  mbinyhi = static_cast<int>(coord * bininvy);

  coord = atom.box.zlo - cutneigh - SMALL * zprd;
  mbinzlo = static_cast<int>(coord * bininvz);

  if(coord < 0.0) mbinzlo = mbinzlo - 1;

  coord = atom.box.zhi + cutneigh + SMALL * zprd;
  mbinzhi = static_cast<int>(coord * bininvz);

  /* extend bins by 1 in each direction to insure stencil coverage */

  mbinxlo = mbinxlo - 1;
  mbinxhi = mbinxhi + 1;
  mbinx = mbinxhi - mbinxlo + 1;

  mbinylo = mbinylo - 1;
  mbinyhi = mbinyhi + 1;
  mbiny = mbinyhi - mbinylo + 1;

  mbinzlo = mbinzlo - 1;
  mbinzhi = mbinzhi + 1;
  mbinz = mbinzhi - mbinzlo + 1;

  /*
  compute bin stencil of all bins whose closest corner to central bin
  is within neighbor cutoff
  for partial Newton (newton = 0),
  stencil is all surrounding bins including self
  for full Newton (newton = 1),
  stencil is bins to the "upper right" of central bin, does NOT include self
  next(xyz) = how far the stencil could possibly extend
  factor < 1.0 for special case of LJ benchmark so code will create
  correct-size stencil when there are 3 bins for every 5 lattice spacings
  */

  nextx = static_cast<int>(cutneigh * bininvx);

  if(nextx * binsizex < FACTOR * cutneigh) nextx++;

  nexty = static_cast<int>(cutneigh * bininvy);

  if(nexty * binsizey < FACTOR * cutneigh) nexty++;

  nextz = static_cast<int>(cutneigh * bininvz);

  if(nextz * binsizez < FACTOR * cutneigh) nextz++;

  nmax = (2 * nextz + 1) * (2 * nexty + 1) * (2 * nextx + 1);
  stencil = tvector_1i("stencil", nmax);
  h_stencil = KokkosArray::create_mirror_view(stencil);
  nstencil = 0;
  MMD_int kstart = -nextz;

  if(halfneigh && ghost_newton) {
    kstart = 0;
    h_stencil(nstencil++) = 0;
  }

  for(k = kstart; k <= nextz; k++) {
    for(j = -nexty; j <= nexty; j++) {
      for(i = -nextx; i <= nextx; i++) {
        if(!ghost_newton || !halfneigh || (k > 0 || j > 0 || (j == 0 && i > 0)))
          if(bindist(i, j, k) < cutneighsq) {
            h_stencil(nstencil++) = k * mbiny * mbinx + j * mbinx + i;
          }
      }
    }
  }

  KokkosArray::deep_copy(stencil, h_stencil);
  mbins = mbinx * mbiny * mbinz;
  bincount = tvector_1i("bincount", mbins * num_omp_threads);
  bins = tvector_1i("bins", mbins * atoms_per_bin);
  f_build = new NeighborBuildFunctor;
  f_binatoms = new NeighborBinatomsFunctor;
  return 0;
}

/* compute closest distance between central bin (0,0,0) and bin (i,j,k) */

KOKKOSARRAY_INLINE_FUNCTION double Neighbor::bindist(MMD_int i, MMD_int j, MMD_int k)
{
  MMD_float delx, dely, delz;

  if(i > 0)
    delx = (i - 1) * binsizex;
  else if(i == 0)
    delx = 0.0;
  else
    delx = (i + 1) * binsizex;

  if(j > 0)
    dely = (j - 1) * binsizey;
  else if(j == 0)
    dely = 0.0;
  else
    dely = (j + 1) * binsizey;

  if(k > 0)
    delz = (k - 1) * binsizez;
  else if(k == 0)
    delz = 0.0;
  else
    delz = (k + 1) * binsizez;

  return (delx * delx + dely * dely + delz * delz);
}

