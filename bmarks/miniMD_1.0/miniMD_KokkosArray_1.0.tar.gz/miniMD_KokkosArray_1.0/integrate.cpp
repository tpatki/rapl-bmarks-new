/* ----------------------------------------------------------------------
   miniMD is a simple, parallel molecular dynamics (MD) code.   miniMD is
   an MD microapplication in the Mantevo project at Sandia National
   Laboratories ( http://www.mantevo.org ). The primary
   authors of miniMD are Steve Plimpton (sjplimp@sandia.gov) , Paul Crozier
   (pscrozi@sandia.gov) and Christian Trott (crtrott@sandia.gov).

   Copyright (2008) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This library is free software; you
   can redistribute it and/or modify it under the terms of the GNU Lesser
   General Public License as published by the Free Software Foundation;
   either version 3 of the License, or (at your option) any later
   version.

   This library is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this software; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
   USA.  See also: http://www.gnu.org/licenses/lgpl.txt .

   For questions, contact Paul S. Crozier (pscrozi@sandia.gov) or
   Christian Trott (crtrott@sandia.gov).

   Please read the accompanying README and LICENSE files.
---------------------------------------------------------------------- */
//#define PRINTDEBUG(a) a
#define PRINTDEBUG(a)
#include "stdio.h"
#include "integrate.h"
#include "math.h"
#include <KokkosArray_Host.hpp>
#include "types.h"

Integrate::Integrate()
{
}

Integrate::~Integrate()
{
}

void Integrate::setup()
{
  f_initialIntegrate = new InitialIntegrateFunctor;
  f_finalIntegrate = new FinalIntegrateFunctor;

  dtforce = 0.5 * dt;
}

void Integrate::finalise()
{
  delete f_initialIntegrate;
  delete f_finalIntegrate;
}

void Integrate::initialIntegrate()
{
  f_initialIntegrate->c = *this;

  //initialIntegrateFull();
  //initialIntegrateFullPlain();
  KokkosArray::parallel_for(nlocal, *f_initialIntegrate);
}

void Integrate::finalIntegrate()
{
  f_finalIntegrate->c = *this;
  KokkosArray::parallel_for(nlocal, *f_finalIntegrate);
}

void Integrate::run(Atom &atom, Force* force, Neighbor &neighbor,
                    Comm &comm, Thermo &thermo, Timer &timer)
{
  mass = atom.mass;
  dtforce = dtforce / mass;
  comm.timer = &timer;
  atom.timer = &timer;
  timer.array[TIME_TEST] = 0.0;

  for(MMD_bigint n = 0; n < ntimes; n++) {
    x = atom.x;
    v = atom.v;
    f = atom.f;
    nlocal = atom.nlocal;
    nmax = atom.nmax;

    initialIntegrate();
    device_type::fence();

    timer.stamp();

    if((n + 1) % neighbor.every) {
      comm.communicate(atom);
      timer.stamp(TIME_COMM);
      //force->reneigh=0;
    } else {

      //      atom.download(DATA_X | DATA_V);
      comm.exchange(atom);
      comm.borders(atom);
      //      atom.upload(DATA_X | DATA_V);
      device_type::fence();
      timer.stamp(TIME_COMM);
      neighbor.build(atom);
      device_type::fence();

      timer.stamp(TIME_NEIGH);
      // force->reneigh=1;
    }

    force->evflag = (n + 1) % thermo.nstat == 0;
    force->compute(atom, neighbor, comm, comm.me);
    device_type::fence();


    timer.stamp(TIME_FORCE);

    if(neighbor.halfneigh && neighbor.ghost_newton) {
      timer.stamp_extra_start();
      comm.reverse_communicate(atom);

      timer.stamp_extra_stop(TIME_TEST);
      timer.stamp(TIME_COMM);
    }

    v = atom.v;
    f = atom.f;
    nlocal = atom.nlocal;

    finalIntegrate();
    device_type::fence();

    if(thermo.nstat) thermo.compute(n + 1, atom, neighbor, force, timer, comm);

    device_type::fence();

  }
}

KOKKOSARRAY_INLINE_FUNCTION void Integrate::initialIntegrateItem(const MMD_int &i) const
{
  //printf("int1: %i // %lf %lf %lf // %lf %lf %lf // %lf %lf %lf // %lf %lf\n",i,x(i,0),x(i,1),x(i,2),v(i,0),v(i,1),v(i,2),f(i,0),f(i,1),f(i,2),dt,dtforce);
  v(i, 0) += dtforce * f(i, 0);
  v(i, 1) += dtforce * f(i, 1);
  v(i, 2) += dtforce * f(i, 2);
  x(i, 0) += dt * v(i, 0);
  x(i, 1) += dt * v(i, 1);
  x(i, 2) += dt * v(i, 2);
}

//vectorizes with #pragma ivdep only
inline void Integrate::initialIntegrateFull() const
{
#if DEVICE==1
  const MMD_int end = nlocal;
#pragma ivdep

  for(MMD_int i = 0; i < end; i++) {
    x(i, 0) += dt * v(i, 0);
    x(i, 1) += dt * v(i, 1);
    x(i, 2) += dt * v(i, 2);
  }

#endif
}

//vectorizes when using restrict for xv and vv
inline void Integrate::initialIntegrateFullPlain() const
{
#if DEVICE==1
  const MMD_int end = nlocal;
  MMD_float* xv = x.ptr_on_device();
  MMD_float* vv = v.ptr_on_device();

  for(MMD_int i = 0; i < end; i++) {
    xv[3 * i] += dt * vv[3 * i];
    xv[3 * i + 1] += dt * vv[3 * i + 2];
    xv[3 * i + 2] += dt * vv[3 * i + 2];
  }

#endif
}

KOKKOSARRAY_INLINE_FUNCTION void Integrate::finalIntegrateItem(const MMD_int &i) const
{
  //printf("int2: %i // %lf %lf %lf // %lf %lf %lf // %lf %lf %lf // %lf %lf\n",i,x(i,0),x(i,1),x(i,2),v(i,0),v(i,1),v(i,2),f(i,0),f(i,1),f(i,2),dt,dtforce);

  v(i, 0) += dtforce * f(i, 0);
  v(i, 1) += dtforce * f(i, 1);
  v(i, 2) += dtforce * f(i, 2);
}
