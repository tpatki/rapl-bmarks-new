/* ----------------------------------------------------------------------
   miniMD is a simple, parallel molecular dynamics (MD) code.   miniMD is
   an MD microapplication in the Mantevo project at Sandia National
   Laboratories ( http://www.mantevo.org ). The primary
   authors of miniMD are Steve Plimpton (sjplimp@sandia.gov) , Paul Crozier
   (pscrozi@sandia.gov) and Christian Trott (crtrott@sandia.gov).

   Copyright (2008) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This library is free software; you
   can redistribute it and/or modify it under the terms of the GNU Lesser
   General Public License as published by the Free Software Foundation;
   either version 3 of the License, or (at your option) any later
   version.

   This library is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this software; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
   USA.  See also: http://www.gnu.org/licenses/lgpl.txt .

   For questions, contact Paul S. Crozier (pscrozi@sandia.gov) or
   Christian Trott (crtrott@sandia.gov).

   Please read the accompanying README and LICENSE files.
---------------------------------------------------------------------- */

#ifndef TYPES_H
#define TYPES_H

enum ForceStyle {FORCELJ, FORCEEAM};


#include "KokkosArray_View.hpp"
#include "KokkosArray_Cuda.hpp"
#include "KokkosArray_Macros.hpp"

#ifndef DEVICE
#define DEVICE 1
#endif
#if DEVICE==1
typedef KokkosArray::Host device_type;
struct double2 {
  double x, y;
};
struct float2 {
  float x, y;
};
struct double4 {
  double x, y, z, w;
};
struct float4 {
  float x, y, z, w;
};
#define KokkosArrayHost(a) a
#define KokkosArrayCUDA(a)
#define MODE 1
#else
#include "cuda.h"
#include "cuda_runtime.h"
typedef KokkosArray::Cuda device_type;
#define KokkosArrayHost(a)
#define KokkosArrayCUDA(a) a
#define MODE 4
#endif


#ifndef PRECISION
#define PRECISION 2
#endif
#if PRECISION==1
typedef float MMD_float;
typedef float2 MMD_float2;
typedef float4 MMD_float4;
#else
typedef double MMD_float;
typedef double2 MMD_float2;
typedef double4 MMD_float4;
#endif
typedef int MMD_int;
typedef int MMD_bigint;





#define PADDING 3

//Choose Layout

//Scalars
typedef KokkosArray::View<MMD_float[1] , KokkosArray::LayoutRight, device_type>  tscalar_d ;
typedef tscalar_d::HostMirror  tscalar_d_host ;
typedef KokkosArray::View<MMD_int[1] , KokkosArray::LayoutRight, device_type>  tscalar_i ;
typedef tscalar_i::HostMirror  tscalar_i_host ;


//2d float array n*PADDING
typedef KokkosArray::View<MMD_float*[PADDING] , KokkosArray::LayoutRight, device_type>  tvector_2d ;
typedef tvector_2d::HostMirror  tvector_2d_host ;
typedef KokkosArray::View<const MMD_float*[PADDING] , KokkosArray::LayoutRight, device_type>  tvector_2d_const ;

//2d float array n*m
typedef KokkosArray::View<MMD_float** , KokkosArray::LayoutRight, device_type >  tvector_2d_o ;
typedef tvector_2d_o::HostMirror  tvector_2d_o_host ;

//1d float array
typedef KokkosArray::View<MMD_float* , KokkosArray::LayoutLeft, device_type >  tvector_1d ;
typedef tvector_1d::HostMirror  tvector_1d_host ;

//1d int array
typedef KokkosArray::View<MMD_int* , KokkosArray::LayoutLeft, device_type >  tvector_1i ;
typedef tvector_1i::HostMirror  tvector_1i_host ;

//2d int array
typedef KokkosArray::View<MMD_int** , KokkosArray::LayoutRight, device_type >  tvector_2i ;
typedef tvector_2i::HostMirror  tvector_2i_host ;


typedef KokkosArray::View<MMD_int[3][3] , KokkosArray::LayoutLeft, device_type >  tvector_procneigh ;
typedef KokkosArray::View<MMD_int[3] , KokkosArray::LayoutLeft, device_type >  tvector_1i3 ;

//neighbor arrays
#if DEVICE==1
typedef KokkosArray::View<MMD_int** , KokkosArray::LayoutRight, device_type >  tvector_neighbors ;
#endif
#if DEVICE==2
typedef KokkosArray::View<MMD_int** , KokkosArray::LayoutLeft, device_type >  tvector_neighbors ;
#endif

template <class T, int rank = T::Rank >
struct DeepCopyFunctor;

template <class T>
struct DeepCopyFunctor<T, 1> {
  typedef typename T::device_type                   device_type ;
  T x;
  T y;

  KOKKOSARRAY_INLINE_FUNCTION
  void operator()(const MMD_int ii) const {
    x(ii) = y(ii);
  }
};

template <class T>
struct DeepCopyFunctor<T, 2> {
  typedef typename T::device_type                   device_type ;
  T x;
  T y;

  KOKKOSARRAY_INLINE_FUNCTION
  void operator()(const MMD_int ii) const {
    int i = ii / y.dimension(1);
    int j = ii % y.dimension(1);
    x(i, j) = y(i, j);
  }
};

template <class T>
struct DeepCopyFunctor<T, 3> {
  typedef typename T::device_type                   device_type ;
  T x;
  T y;

  KOKKOSARRAY_INLINE_FUNCTION
  void operator()(const MMD_int ii) const {
    int i = ii / (y.dimension(1) * y.dimension(2));
    int j = ii % (y.dimension(1) * y.dimension(2));
    int k = j % y.dimension(2);
    j = j / y.dimension(2);
    x(i, j, k) = y(i, j, k);
  }
};

template <class T>
void deep_copy_grow(T x, T y)
{
  if((x.ptr_on_device() == NULL) || (y.ptr_on_device() == NULL)) return;

  int nthreads = 1;

  for(int i = 0; i < x.rank(); i++) {
    if(x.dimension(i) < y.dimension(i)) return;

    nthreads *= y.dimension(i);
  }

  DeepCopyFunctor<T> f;
  f.x = x;
  f.y = y;
  KokkosArray::parallel_for(nthreads, f);
}

void cuda_check_error(char* comment);

//Texture fetchs
#if DEVICE==2
#if PRECISION==1
static __device__ inline MMD_float4 tex1Dfetch_f4(texture<float4, 1> t, const int &i)
{
  return tex1Dfetch(t, i);
}
static __device__ inline MMD_float tex1Dfetch_f1(texture<float, 1> t, const int &i)
{
  return tex1Dfetch(t, i);
}

#if CUDA_ARCH >= 300
static __device__ inline MMD_float4 tex1Dfetch_f4o(const cudaTextureObject_t &t, const int &i)
{
  return tex1Dfetch<MMD_float4>(t, i);
}
static __device__ inline MMD_float tex1Dfetch_f1o(const cudaTextureObject_t &t, const int &i)
{
  return tex1Dfetch<MMD_float>(t, i);
}
#endif
#endif

#if PRECISION==2
static __device__ inline MMD_float4 tex1Dfetch_f4(texture<int4, 1> t, int i)
{
  int4 v = tex1Dfetch(t, 2 * i);
  int4 u = tex1Dfetch(t, 2 * i + 1);
  MMD_float4 w;

  w.x = __hiloint2double(v.y, v.x);
  w.y = __hiloint2double(v.w, v.z);
  w.z = __hiloint2double(u.y, u.x);
  w.w = __hiloint2double(u.w, u.z);
  return w;
}
static __device__ inline MMD_float tex1Dfetch_f1(texture<int2, 1> t, int i)
{
  int2 v = tex1Dfetch(t, i);
  MMD_float w;

  w = __hiloint2double(v.y, v.x);
  return w;
}

#if CUDA_ARCH >= 300
static __device__ inline MMD_float4 tex1Dfetch_f4o(cudaTextureObject_t t, int i)
{
  int4 v = tex1Dfetch<int4>(t, 2 * i);
  int4 u = tex1Dfetch<int4>(t, 2 * i + 1);
  MMD_float4 w;

  w.x = __hiloint2double(v.y, v.x);
  w.y = __hiloint2double(v.w, v.z);
  w.z = __hiloint2double(u.y, u.x);
  w.w = __hiloint2double(u.w, u.z);
  return w;
}
static __device__ inline MMD_float tex1Dfetch_f1o(cudaTextureObject_t t, int i)
{
  int2 v = tex1Dfetch<int2>(t, i);
  MMD_float w;

  w = __hiloint2double(v.y, v.x);
  return w;
}
#endif
#endif
#endif

#endif
