/* ----------------------------------------------------------------------
   miniMD is a simple, parallel molecular dynamics (MD) code.   miniMD is
   an MD microapplication in the Mantevo project at Sandia National
   Laboratories ( http://www.mantevo.org ). The primary
   authors of miniMD are Steve Plimpton (sjplimp@sandia.gov) , Paul Crozier
   (pscrozi@sandia.gov) and Christian Trott (crtrott@sandia.gov).

   Copyright (2008) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This library is free software; you
   can redistribute it and/or modify it under the terms of the GNU Lesser
   General Public License as published by the Free Software Foundation;
   either version 3 of the License, or (at your option) any later
   version.

   This library is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this software; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
   USA.  See also: http://www.gnu.org/licenses/lgpl.txt .

   For questions, contact Paul S. Crozier (pscrozi@sandia.gov) or
   Christian Trott (crtrott@sandia.gov) or
   Christian Trott (crtrott@sandia.gov).

   Please read the accompanying README and LICENSE files.
---------------------------------------------------------------------- */

#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "mpi.h"
#include "atom.h"

#define DELTA 10000


void cuda_check_error(char* comment)
{
#if DEVICE==1
  printf("ERROR %s in %s:%i\n", comment, __FILE__, __LINE__);
#endif
#if DEVICE==2
  printf("ERROR-CUDA %s %s in %s:%i\n", comment, cudaGetErrorString(cudaGetLastError()), __FILE__, __LINE__);
#endif

}

Atom::Atom()
{
  natoms = 0;
  nlocal = 0;
  nghost = 0;
  nmax = 0;

  comm_size = 3;
  reverse_size = 3;
  border_size = 3;

  mass = 1;
}

void Atom::setup()
{
  f_pbc = new AtomPBCFunctor;
  f_pack_comm = new AtomPackCommFunctor;
  f_pack_comm_pbc = new AtomPackCommPBCFunctor;
  f_unpack_comm = new AtomUnpackCommFunctor;
  f_pack_reverse = new AtomPackReverseFunctor;
  f_unpack_reverse = new AtomUnpackReverseFunctor;
}

void Atom::finalise()
{
  delete f_pbc;
  delete f_pack_comm;
  delete f_pack_comm_pbc;
  delete f_unpack_comm;
  delete f_pack_reverse;
  delete f_unpack_reverse;
}

Atom::~Atom()
{
}

void Atom::growarray(MMD_int host_current)
{
  nmax += DELTA;

  if(host_current) {

    x = tvector_2d("X", nmax);
    v = tvector_2d("V", nmax);
    f = tvector_2d("F", nmax);

    tvector_2d_host xnew = KokkosArray::create_mirror_view(x);
    tvector_2d_host vnew = KokkosArray::create_mirror_view(v);
    tvector_2d_host fnew = KokkosArray::create_mirror_view(f);

    deep_copy_grow(xnew, h_x);
    deep_copy_grow(vnew, h_v);
    deep_copy_grow(fnew, h_f);

    h_x = xnew;
    h_v = vnew;
    h_f = fnew;
  } else {

    tvector_2d xnew("X", nmax);
    tvector_2d vnew("V", nmax);
    tvector_2d fnew("F", nmax);

    deep_copy_grow(xnew, x);
    deep_copy_grow(vnew, v);
    deep_copy_grow(fnew, f);

    x = xnew;
    v = vnew;
    f = fnew;

    h_x = KokkosArray::create_mirror_view(x);
    h_v = KokkosArray::create_mirror_view(v);
    h_f = KokkosArray::create_mirror_view(f);
  }

  if(x == NULL || v == NULL || f == NULL) {
    printf("ERROR: No memory for atoms\n");
  }
}

void Atom::growarray(MMD_int host_current, MMD_int newsize)
{
  if(newsize <= nmax) return;

  nmax = newsize;
  growarray(host_current);
}

void Atom::addatom(MMD_float x_in, MMD_float y_in, MMD_float z_in,
                   MMD_float vx_in, MMD_float vy_in, MMD_float vz_in)
{
  if(nlocal == nmax) {
    growarray(1);
  }

  h_x(nlocal, 0) = x_in;
  h_x(nlocal, 1) = y_in;
  h_x(nlocal, 2) = z_in;
  h_v(nlocal, 0) = vx_in;
  h_v(nlocal, 1) = vy_in;
  h_v(nlocal, 2) = vz_in;

  nlocal++;
}

/* enforce PBC
   order of 2 tests is important to insure lo-bound <= coord < hi-bound
   even with round-off errors where (coord +/- epsilon) +/- period = bound */

KOKKOSARRAY_INLINE_FUNCTION
void Atom::pbcItem(const MMD_int &i) const
{
  if(x(i, 0) < 0.0) x(i, 0) += box.xprd;

  if(x(i, 0) >= box.xprd) x(i, 0) -= box.xprd;

  if(x(i, 1) < 0.0) x(i, 1) += box.yprd;

  if(x(i, 1) >= box.yprd) x(i, 1) -= box.yprd;

  if(x(i, 2) < 0.0) x(i, 2) += box.zprd;

  if(x(i, 2) >= box.zprd) x(i, 2) -= box.zprd;

}

void Atom::pbc()
{

  f_pbc->c = *this;

  KokkosArray::parallel_for(nlocal, *f_pbc);
}

void Atom::copy(MMD_int i, MMD_int j)
{
  h_x(j, 0) = h_x(i, 0);
  h_x(j, 1) = h_x(i, 1);
  h_x(j, 2) = h_x(i, 2);
  h_v(j, 0) = h_v(i, 0);
  h_v(j, 1) = h_v(i, 1);
  h_v(j, 2) = h_v(i, 2);
}

void Atom::pack_comm(MMD_int n, MMD_int iswap, tvector_1d buf, int* act_pbc_flags, tvector_2i asendlist)
{
  actswap = iswap;
  sendlist = asendlist;
  pbc_flags[0] = act_pbc_flags[0];
  pbc_flags[1] = act_pbc_flags[1];
  pbc_flags[2] = act_pbc_flags[2];
  pbc_flags[3] = act_pbc_flags[3];

  actbuf = buf;

  if(pbc_flags[0] == 0) {
    f_pack_comm->c = *this;
    //KokkosArray::parallel_for(0,*f_pack_comm);
    KokkosArray::parallel_for(n, *f_pack_comm);
  } else {
    f_pack_comm_pbc->c = *this;
    //KokkosArray::parallel_for(0,*f_pack_comm_pbc);
    KokkosArray::parallel_for(n, *f_pack_comm_pbc);
  }
}

KOKKOSARRAY_INLINE_FUNCTION void Atom::pack_commItem(const MMD_int &i) const
{
  const MMD_int j = sendlist(actswap, i);
  actbuf[3 * i] = x(j, 0);
  actbuf[3 * i + 1] = x(j, 1);
  actbuf[3 * i + 2] = x(j, 2);
}

KOKKOSARRAY_INLINE_FUNCTION void Atom::pack_commItemPBC(const MMD_int &i) const
{
  const MMD_int j = sendlist(actswap, i);;
  actbuf[3 * i] = x(j, 0) + pbc_flags[1] * box.xprd;
  actbuf[3 * i + 1] = x(j, 1) + pbc_flags[2] * box.yprd;
  actbuf[3 * i + 2] = x(j, 2) + pbc_flags[3] * box.zprd;
}

void Atom::unpack_comm(MMD_int n, MMD_int actfirst, tvector_1d buf)
{
  first = actfirst;
  actbuf = buf;

  f_unpack_comm->c = *this;
  //KokkosArray::parallel_for(0,*f_unpack_comm);
  KokkosArray::parallel_for(n, *f_unpack_comm);
}

KOKKOSARRAY_INLINE_FUNCTION void Atom::unpack_commItem(const MMD_int &i) const
{
  x(first + i, 0) = actbuf[3 * i];
  x(first + i, 1) = actbuf[3 * i + 1];
  x(first + i, 2) = actbuf[3 * i + 2];
}

void Atom::pack_reverse(MMD_int n, MMD_int actfirst, tvector_1d buf)
{
  first = actfirst;
  actbuf = buf;

  f_pack_reverse->c = *this;

  //KokkosArray::parallel_for(0,*f_pack_reverse);
  KokkosArray::parallel_for(n, *f_pack_reverse);
}

KOKKOSARRAY_INLINE_FUNCTION void Atom::pack_reverseItem(const MMD_int &i) const
{
  actbuf[3 * i] = f(first + i, 0);
  actbuf[3 * i + 1] = f(first + i, 1);
  actbuf[3 * i + 2] = f(first + i, 2);
}

void Atom::unpack_reverse(MMD_int n, MMD_int iswap, tvector_1d buf, tvector_2i asendlist)
{
  actswap = iswap;
  sendlist = asendlist;
  actbuf = buf;

  f_unpack_reverse->c = *this;

  //KokkosArray::parallel_for(0,*f_unpack_reverse);
  KokkosArray::parallel_for(n, *f_unpack_reverse);
}

KOKKOSARRAY_INLINE_FUNCTION void Atom::unpack_reverseItem(const MMD_int &i) const
{
  MMD_int j = sendlist(actswap, i);
  f(j, 0) += actbuf[3 * i];
  f(j, 1) += actbuf[3 * i + 1];
  f(j, 2) += actbuf[3 * i + 2];
}

int Atom::pack_border(MMD_int i, MMD_float* buf, int* pbc_flags)
{
  int m = 0;

  if(pbc_flags[0] == 0) {
    buf[m++] = h_x(i, 0);
    buf[m++] = h_x(i, 1);
    buf[m++] = h_x(i, 2);
  } else {
    buf[m++] = h_x(i, 0) + pbc_flags[1] * box.xprd;
    buf[m++] = h_x(i, 1) + pbc_flags[2] * box.yprd;
    buf[m++] = h_x(i, 2) + pbc_flags[3] * box.zprd;
  }

  return m;
}

int Atom::unpack_border(MMD_int i, MMD_float* buf)
{
  if(i == nmax) growarray(1);

  int m = 0;
  h_x(i, 0) = buf[m++];
  h_x(i, 1) = buf[m++];
  h_x(i, 2) = buf[m++];
  return m;
}

int Atom::pack_exchange(MMD_int i, MMD_float* buf)
{
  MMD_int m = 0;
  buf[m++] = h_x(i, 0);
  buf[m++] = h_x(i, 1);
  buf[m++] = h_x(i, 2);
  buf[m++] = h_v(i, 0);
  buf[m++] = h_v(i, 1);
  buf[m++] = h_v(i, 2);
  return m;
}

int Atom::unpack_exchange(MMD_int i, MMD_float* buf)
{
  if(i == nmax) growarray(1);

  MMD_int m = 0;
  h_x(i, 0) = buf[m++];
  h_x(i, 1) = buf[m++];
  h_x(i, 2) = buf[m++];
  h_v(i, 0) = buf[m++];
  h_v(i, 1) = buf[m++];
  h_v(i, 2) = buf[m++];
  return m;
}

int Atom::skip_exchange(MMD_float* buf)
{
  return 6;
}

void Atom::upload(int datamask)
{
  if(nlocal == 0) return;

  if(datamask & DATA_X) KokkosArray::deep_copy(x, h_x);

  if(datamask & DATA_V) KokkosArray::deep_copy(v, h_v);

  if(datamask & DATA_F) KokkosArray::deep_copy(f, h_f);
}

void Atom::download(int datamask)
{
  if(nlocal == 0) return;

  if(datamask & DATA_X) KokkosArray::deep_copy(h_x, x);

  if(datamask & DATA_V) KokkosArray::deep_copy(h_v, v);

  if(datamask & DATA_F) KokkosArray::deep_copy(h_f, f);
}
/* realloc a 2-d MMD_float array */


